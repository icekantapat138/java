package ku.cs.emailsystem.model;

public class Mail {
    private String sender;
    private String text;

    public Mail(String sender, String text) {
        this.sender = sender;
        this.text = text;
    }

    public String getSender() {
        return sender;
    }

    public String getText() {
        return text;
    }
}
