package ku.cs.emailsystem.model;

import java.util.ArrayList;

public class Inbox {
    private ArrayList<Mail> mail;

    public Inbox() {
        mail = new ArrayList<>();
    }

    public void addMail(String sender, String text) {
        Mail mails = new Mail(sender, text);
        this.mail.add(mails);
    }
}
