//package ku.cs.emailsystem.controller;
//
//import ku.cs.emailsystem.model.EmailSystem;
//import ku.cs.emailsystem.model.EmailSysytemView;
//
//public class Main {
//    public static void main(String[] args) {
//        EmailSysytemView view = new EmailSysytemView();
//        EmailSystem emailSystem = new EmailSystem();
//        while(true) {
//            String input = view.readMenu();
//            if (input.equals("Q")) {
//                break;
//            }
//            if (input.equals("I")) {
//                String username = view.readUsername();
//                emailSystem.login(username);
//            } else if (input.equals("O")) {
//                emailSystem.logout();
//            } else if (input.equals("S")) {
//                if(emailSystem.getCurrentUser() == null) {
//                    view.alert("Please Login First");
//                    continue;
//                }
//                String recipient = view.readReciepient();
//                String text = view.readText();
//                emailSystem.sendMail(recipient, text);
//            } else if (input.equals("R")) {
//                view.printMails(emailSystem.getCurrentUser(), emailSystem.readMail());
//            }
//        } System.out.println("====== Good Bye======");
//        }
//    }
//}
