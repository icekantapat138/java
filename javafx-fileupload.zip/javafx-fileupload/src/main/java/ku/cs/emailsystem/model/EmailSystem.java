//package ku.cs.emailsystem.model;
//
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;
//
//public class EmailSystem {
//
//    // composition
//    private Map<String, Inbox> inboxes;
//    private String currentUser;
//
//    public String getCurrentUser() {
//        return currentUser;
//    }
//
//    public EmailSystem() {
//        inboxes = new HashMap<>();
//    }
//
//    public void login(String username){
//        currentUser = username;
//        if (inboxes.containsKey(username)) {
//            inboxes.put(username, new Inbox());
//        }
//    }
//
//    public void logout() {
//        currentUser = null;
//    }
//
//    public void sendMail(String recipient, String text) {
//        if (currentUser == null){
//            throw new IllegalArgumentException("Please login first");
//        }
//        if(inboxes.containsKey(recipient)){
//            inboxes.put(recipient, new Inbox());
//        }
//        //deligation
//        inboxes.get(recipient).addMail(currentUser, text);
//    }
//
//    public ArrayList<Mail> readMail() {
//        if (currentUser == null){
//            throw new IllegalArgumentException("Please login first");
//        }
//        return inboxes.get(currentUser).getMails();
//    }
//}
