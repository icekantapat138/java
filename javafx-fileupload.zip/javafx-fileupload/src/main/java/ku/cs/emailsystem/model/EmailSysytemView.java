//package ku.cs.emailsystem.model;
//
//import java.util.Scanner;
//
//public class EmailSysytemView {
//    private Scanner in;
//
//    public EmailSysytemView() {
//        System.out.println("====== SWCon Email System======");
//        in = new Scanner(System.in);
//    }
//
//    private void printMenu() {
//        System.out.println("-----> Command (Log I)n S)end R)ead Log O)ut Q)uit: ");
//    }
//
//    public String readMenu() {
//        printMenu();
//        String input = in.nextLine();
//        return input;
//    }
//
//    public String readUsername() {
//
//    }
//
//    public String readReciepient() {
//
//    }
//
//    public String readText() {
//
//    }
//
//    public String readMails() {
//
//    }
//
//    public void printMails() {
//
//    }
//
//
//}
