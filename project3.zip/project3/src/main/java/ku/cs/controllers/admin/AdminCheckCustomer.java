package ku.cs.controllers.admin;

import com.github.saacsos.FXRouter;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ku.cs.model.User.CustomerAccount;
import ku.cs.model.User.CustomerAccountList;
import ku.cs.service.StringConfiguration;
import ku.cs.service.fileaccount.CustomerFileDataSource;
import ku.cs.service.fileaccount.FileAccountDataSource;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AdminCheckCustomer {
    @FXML private ListView<CustomerAccount> customerview;
    @FXML private TextField firstnameTxt;
    @FXML private TextField lastnameTxt;
    @FXML private TextField usernameTxt;
    @FXML private TextField storeTxt;
    @FXML private TextField loginTxt;

    private CustomerAccountList customerAccountList;
    private CustomerFileDataSource dataSource;

    @FXML
    public void initialize() {
        dataSource = new CustomerFileDataSource("data", "customer.csv");
        customerAccountList = dataSource.readData();
        System.out.println(customerAccountList.getAllCustomer());
        System.out.println(System.getProperty("user.dir"));
        clearSelectedCustomer();
        handleSelectedListView();
        showCustomerData();
    }

    private void handleSelectedListView() {
        customerview.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<CustomerAccount>() {
            @Override
            public void changed(ObservableValue<? extends CustomerAccount> observableValue, CustomerAccount customerAccount, CustomerAccount t1) {
                System.out.println(t1 + " is selected.");
                showSelectedCustomer(t1);
            }
        });
    }

    private void showCustomerData() {
        customerview.getItems().addAll(customerAccountList.getAllCustomer());
        customerview.refresh();
    }

    private void showSelectedCustomer(CustomerAccount css){
        usernameTxt.setText(css.getFirstname());
        firstnameTxt.setText(css.getPassword());
        lastnameTxt.setText(css.getPassword());
        storeTxt.setText(css.getStatus());
        loginTxt.setText(css.getDate());
    }

    private void clearSelectedCustomer() {
        usernameTxt.setText("");
        firstnameTxt.setText("");
        lastnameTxt.setText("");
        storeTxt.setText("");
        loginTxt.setText("");
    }

    @FXML
    public void backBtn(ActionEvent event) throws IOException {
        FXRouter.goTo("admincontroller");
    }
}
