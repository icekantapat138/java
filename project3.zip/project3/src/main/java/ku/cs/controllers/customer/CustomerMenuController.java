package ku.cs.controllers.customer;

import com.github.saacsos.FXRouter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import ku.cs.model.User.CustomerAccount;
import ku.cs.service.fileaccount.CustomerFileDataSource;
import ku.cs.service.fileaccount.FileAccountDataSource;

import java.io.IOException;

public class CustomerMenuController {

    private CustomerFileDataSource css;
    private CustomerAccount customerAccount;

    @FXML
    public void initialize() {
        css = new CustomerFileDataSource("data", "customer.csv");
        css.readData();
    }

    @FXML
    void storeBtn(ActionEvent event) throws IOException {
        FXRouter.goTo("storecreate");
    }

    @FXML
    void logoutBtn(ActionEvent event) throws IOException {
        FXRouter.goTo("startprogram");
    }

    @FXML
    void shopBtn(ActionEvent event) throws IOException {
        FXRouter.goTo("shop");
    }

}
