package ku.cs.controllers.customer;

import com.github.saacsos.FXRouter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import ku.cs.model.User.CustomerAccount;
import ku.cs.model.User.CustomerAccountList;
import ku.cs.service.fileaccount.CustomerFileDataSource;
import ku.cs.service.fileaccount.FileAccountDataSource;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class CustomerCreateController {

    @FXML private TextField firstnameText;
    @FXML private TextField lastnameText;
    @FXML private TextField usernameText;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField retypepwField;
    @FXML private ImageView image1;
    @FXML private TextField imageTextField;

    private CustomerAccountList customerAccountList;
    private FileAccountDataSource<CustomerAccountList> dataSource;
    private CustomerAccount selectedCustomer;

    @FXML
    public void initialize() {
        System.out.println(System.getProperty("user.dir"));
        image1.setImage(new Image(getClass().getResource("/images/defaultprofile.jpg").toExternalForm()));
    }

    @FXML
    public void backBtn(ActionEvent event) throws IOException {
        FXRouter.goTo("customerlogin");
    }

    @FXML
    public void browseimageBtn(ActionEvent event) {
        FileChooser chooser = new FileChooser();
        // SET FILECHOOSER INITIAL DIRECTORY
        chooser.setInitialDirectory(new File(System.getProperty("user.dir")));
        // DEFINE ACCEPTABLE FILE EXTENSION
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("images PNG JPG", "*.png", "*.jpg", "*.jpeg"));
        // GET FILE FROM FILECHOOSER WITH JAVAFX COMPONENT WINDOW
        Node source = (Node) event.getSource();
        File file = chooser.showOpenDialog(source.getScene().getWindow());
        if (file != null){
            try {
                // CREATE FOLDER IF NOT EXIST
                File destDir = new File("images");
                if (!destDir.exists()) destDir.mkdirs();
                // RENAME FILE
                String[] fileSplit = file.getName().split("\\.");
                String filename = LocalDate.now() + "_"+System.currentTimeMillis() + "."
                        + fileSplit[fileSplit.length - 1];
                Path target = FileSystems.getDefault().getPath(
                        destDir.getAbsolutePath()+System.getProperty("file.separator")+filename
                );
                // COPY WITH FLAG REPLACE FILE IF FILE IS EXIST
                Files.copy(file.toPath(), target, StandardCopyOption.REPLACE_EXISTING );
                image1.setImage(new Image(target.toUri().toString()));
                selectedCustomer.setImage(destDir + "/" + filename) ;
                imageTextField.setText(filename);
            }catch (IOException e){
                e.printStackTrace();
            }
        }

    }

    @FXML
    void createBtn(ActionEvent event) throws IOException {
        dataSource = new CustomerFileDataSource("data", "customer.csv");
        CustomerAccountList accountList = dataSource.readData();
        if ((firstnameText.getText().equals("") || (lastnameText.getText().equals("") || (usernameText.getText().equals("") || (passwordField.getText().equals("")) || (retypepwField.getText().equals("") || (imageTextField.getText().equals(""))))))){
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("Please Complete All Field.");
            alert1.setContentText("Please!! Enter All Field To Create Account.");
            alert1.showAndWait();
        }else {
            if (!(passwordField.getText().equals(retypepwField.getText()))){
                System.out.println("Not Pass");
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Re-Password Not Match Password");
                alert1.setContentText("Password And Re-Password Not Match.");
                alert1.showAndWait();
            }else {
                if(accountList.checkUsernameAccount(usernameText.getText())) {
                    Alert err = new Alert(Alert.AlertType.ERROR);
                    err.setTitle("ERROR");
                    err.setContentText("This Username Has Use.");
                    err.showAndWait();
                }else {
                    System.out.println("Pass");
                    dataSource = new CustomerFileDataSource();
                    CustomerAccountList customerAccountList = dataSource.readData();
                    CustomerAccount css = new CustomerAccount(
                            usernameText.getText(),
                            passwordField.getText(),
                            firstnameText.getText(),
                            lastnameText.getText(),
                            retypepwField.getText(),
                            imageTextField.getText(),
                            "Not Have Store",
                            "No Login Yet.");
                    System.out.println(css.toCsv());

                    customerAccountList.addCustomerAccount(css);
                    dataSource.writeData(customerAccountList);


                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("CONFIRMATION");
                    confirm.setContentText("Create Account Successful.");
                    confirm.showAndWait();
                    clearAllField();
                    FXRouter.goTo("customerlogin");
                }
            }
        }
    }

    private void clearAllField() {
        firstnameText.clear();
        lastnameText.clear();
        usernameText.clear();
        passwordField.clear();
        retypepwField.clear();
        imageTextField.setText("");
        image1.setImage(image1.getImage());
    }
}
