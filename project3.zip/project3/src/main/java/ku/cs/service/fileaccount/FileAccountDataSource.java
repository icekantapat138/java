package ku.cs.service.fileaccount;

import ku.cs.model.User.AdminAccountList;

public interface FileAccountDataSource<T> {
    T readData();
    void writeData(T t);
}
