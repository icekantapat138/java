package ku.cs.model.User;

public class AdminAccount {

    private String username;
    private String password;

    public AdminAccount(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String toCsv() {
        return "Admin," + "," + username + "," + password;
    }
}
