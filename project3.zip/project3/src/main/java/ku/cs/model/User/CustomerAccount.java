package ku.cs.model.User;

import javafx.beans.property.StringProperty;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CustomerAccount {

    private String username;
    private String password;
    private String firstname;
    private String lastname;
    private String repassword;
    private String image;
    private String status;
    private String date;


    public CustomerAccount(String username, String password, String firstname, String lastname, String repassword, String image, String status, String date){
        this.username = username;
        this.password = password;
        this.firstname = firstname;
        this.lastname = lastname;
        this.repassword = repassword;
        this.image = getClass().getResource("images/defaultprofile.jpg").toExternalForm();
        this.status = status;
        this.date = date;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getRepassword() {
        return repassword;
    }

    public String getImage() {
        return image;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }

    public void setStatusHaveStore() {
        this.status = "Have Store";
    }

    public void setStatusNotHaveStore() {
        this.status = "Not Have Store";
    }

    public void setImage(String image){
        this.image = image;
    }

    public void setDate() {
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("dd.mm.yyyy,kk.mm.ss");
        this.date = formatTime.format(currentTime);
    }

    public boolean checkUser(String username){
        return this.username.equals(username);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean checkPw(String password){
        return this.password.equals(password);
    }

    public int checkStatus(CustomerAccountList status) {
        if (getStatus() == "Have Store") {
            return 1;
        } else if (getStatus() == "Not Have Store") {
            return 2;
        }else {
            return 0;
        }
    }

    public String toCsv() {
        return username +
                "," + password + "," + firstname +
                "," + lastname + "," + repassword +
                "," + image + "," + status +
                "," + date;
    }

    public String toString() {
        return firstname + "," + lastname + "," + username;
    }
}
