package ku.cs.model.User;

import java.util.ArrayList;

public class CustomerAccountList {

    private ArrayList<CustomerAccount> customerList;

    public CustomerAccountList() {
        customerList = new ArrayList<>();
    }

    public void addCustomerAccount(CustomerAccount css){
        customerList.add(css);
    }

    public ArrayList<CustomerAccount> getAllCustomer() {
        return customerList;
    }

    public CustomerAccount searchUser(String username){
        for(CustomerAccount css : customerList){
            if(css.checkUser(username)){
                return css;
            }
        }
        return null;
    }

    public boolean checkUsernameAccount(String username){
        CustomerAccount css = searchUser(username);
        if(css.checkUser(username)){
            return true;
        }
        return false;
    }

    public boolean checkUserandPw(String username, String password){
        CustomerAccount css = searchUser(username);
        if(css.checkUser(username) && css.checkPw(password)){
            return true;
        }
        return false;
    }

    public int countCustomer() {
        return customerList.size();
    }

    public String toCsv() {
        String result = "";
        for (CustomerAccount cssacc : this.customerList) {
            result += cssacc.toCsv() + "\n";
        }
        return result;
    }

    @Override
    public String toString() {
        return "CustomerAccountListModelClass{" +
                "customerList=" + customerList +
                '}';
    }
}
