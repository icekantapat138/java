package ku.cs.model.User;

import java.util.ArrayList;

public class AdminAccountList {
    private ArrayList<AdminAccount> adminAccount;

    public AdminAccountList() {
        adminAccount = new ArrayList<>();
    }

    public void addAdminAccount(AdminAccount acc) {
        adminAccount.add(acc);
    }

    public ArrayList<AdminAccount> getAllAdminAccount() {
        return adminAccount;
    }

    public int countAdminAccount() {
        return adminAccount.size();
    }

    public String toCsv() {
        String result = "";
        for (AdminAccount adacc : this.adminAccount){
            result += adacc.toCsv();
        }
        return result;
    }

    @Override
    public String toString() {
        return "AdminAccountListModelClass{" +
                "adminAccount=" + adminAccount +
                '}';
    }
}
